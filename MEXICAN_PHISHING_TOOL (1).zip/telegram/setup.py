
import os

print("\n🤖 Telegram Bot Setup\n")

bot_token = input("🔑 Enter your Telegram Bot Token: ")
chat_id = input("🆔 Enter your Telegram Chat ID: ")

config_data = f"""
# Auto-generated Telegram Config
bot_token = '{bot_token}'
chat_id = '{chat_id}'
"""

os.makedirs("telegram", exist_ok=True)
with open("telegram/config.py", "w") as f:
    f.write(config_data.strip())

print("\n✅ Telegram Bot config saved to telegram/config.py")
