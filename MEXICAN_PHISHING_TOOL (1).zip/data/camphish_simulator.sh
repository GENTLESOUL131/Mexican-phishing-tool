
#!/bin/bash
echo "📷 Starting Camera Bait Page (Simulation Only)..."
echo "🌍 URL: http://localhost/camera"
sleep 2
echo "🛡️ This simulates camera permission bait. Don't use for evil."
