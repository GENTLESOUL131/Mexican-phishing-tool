
#!/bin/bash
echo "🌐 Starting Fake Login Page (Simulation Only)..."
echo "📍 URL: http://localhost/login"
sleep 2
echo "🛡️ Warning: This is a fake page. Do not use on real people."
