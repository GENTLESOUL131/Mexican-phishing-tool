
import os
import sys

def run_protection():
    if os.path.basename(os.getcwd()) != "MEXICAN-PHISHING-TOOL":
        print("🚫 Unauthorized clone detected. Run from original folder.")
        sys.exit()
    if os.path.basename(__file__) != "protection.py":
        print("⚠️ File tampering detected. Exiting...")
        sys.exit()
